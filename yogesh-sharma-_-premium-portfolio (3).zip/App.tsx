import React, { useState, useEffect, useRef } from 'react';
import { ThemeProvider } from './hooks/useTheme';
import Loader from './components/Loader';
import Header from './components/Header';
import Hero from './components/Hero';
import About from './components/About';
import Skills from './components/Skills';
import Projects from './components/Projects';
import Contact from './components/Contact';
import Footer from './components/Footer';
import AnimatedBackground from './components/AnimatedBackground';

const AppContent: React.FC = () => {
  const [loading, setLoading] = useState(true);
  const mainRef = useRef(null);

  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false);
    }, 1500);

    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (!loading && mainRef.current) {
        // This checks if GSAP and ScrollTrigger are available on the window object
        const gsap = (window as any).gsap;
        const ScrollTrigger = (window as any).ScrollTrigger;

        if (gsap && ScrollTrigger) {
            gsap.registerPlugin(ScrollTrigger);

            const animatedElements = gsap.utils.toArray([
                '.hero-text',
                '.hero-card-flipper',
                '.section-title',
                '#about .grid > div', // Animate columns in about section
                '#skills .grid > *', // Animate each skill category
                '#contact .grid > div' // Animate columns in contact section
            ]);

            animatedElements.forEach((el: any) => {
                gsap.from(el, {
                    opacity: 0,
                    y: 50,
                    duration: 1,
                    ease: 'power3.out',
                    scrollTrigger: {
                        trigger: el,
                        start: 'top 85%',
                        toggleActions: 'play none none none',
                    },
                });
            });
        }
    }
  }, [loading]);


  return (
    <>
      {loading && <Loader />}
      <div className={`transition-opacity duration-500 ${loading ? 'opacity-0' : 'opacity-100'}`}>
        <AnimatedBackground />
        <Header />
        <main ref={mainRef} className="text-text-light dark:text-text-dark font-inter">
          <Hero />
          <About />
          <Skills />
          <Projects />
          <Contact />
        </main>
        <Footer />
      </div>
    </>
  );
};


const App: React.FC = () => {
  return (
    <ThemeProvider>
        <AppContent />
    </ThemeProvider>
  );
}

export default App;