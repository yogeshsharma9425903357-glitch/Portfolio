
import React, { useRef, useEffect } from 'react';
import type { Project } from '../types';

interface ProjectCardProps {
  project: Project;
}

const ProjectCard: React.FC<ProjectCardProps> = ({ project }) => {
  const cardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const gsap = (window as any).gsap;
    const ScrollTrigger = (window as any).ScrollTrigger;
    const element = cardRef.current;

    if (gsap && ScrollTrigger && element) {
      gsap.from(element, {
        opacity: 0,
        y: 50,
        duration: 0.8,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: element,
          start: 'top 85%',
          toggleActions: 'play none none none',
        },
      });
    }
  }, []);


  return (
    <div ref={cardRef} className="group relative w-full aspect-video rounded-lg overflow-hidden [perspective:1000px] shadow-lg">
      <div className="absolute inset-0 transition-transform duration-700 [transform-style:preserve-3d] group-hover:[transform:rotateY(-180deg)]">
        {/* Front face */}
        <div className="absolute inset-0 [backface-visibility:hidden]">
          <img src={project.imageUrl} alt={project.title} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-black/40"></div>
          <div className="absolute bottom-0 left-0 p-4">
              <h3 className="text-xl font-bold text-white font-space-grotesk">{project.title}</h3>
          </div>
        </div>
        
        {/* Back face */}
        <div className="absolute inset-0 bg-white/20 dark:bg-surface-dark/20 backdrop-blur-lg [transform:rotateY(180deg)] [backface-visibility:hidden] p-6 flex flex-col justify-center items-center text-center">
            <h3 className="text-xl font-bold font-space-grotesk mb-2 text-primary-strong-light dark:text-primary-strong-dark">{project.title}</h3>
            <p className="text-sm text-text-light dark:text-text-dark/80 mb-4">{project.description}</p>
            <div className="flex gap-3">
                <a href={project.liveUrl} target="_blank" rel="noopener noreferrer" className="bg-primary-light dark:bg-primary-dark text-white dark:text-bg-dark px-4 py-2 text-sm rounded-md hover:bg-primary-strong-light dark:hover:bg-primary-strong-dark transition-colors">Live Demo</a>
                <a href={project.sourceUrl} target="_blank" rel="noopener noreferrer" className="bg-transparent border border-primary-light dark:border-primary-dark text-primary-light dark:text-primary-dark px-4 py-2 text-sm rounded-md hover:bg-primary-light dark:hover:bg-primary-dark hover:text-white dark:hover:text-bg-dark transition-colors">Source Code</a>
            </div>
        </div>
      </div>
    </div>
  );
};

export default ProjectCard;