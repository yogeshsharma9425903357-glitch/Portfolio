
import React from 'react';

const Loader: React.FC = () => {
  return (
    <div className="fixed top-0 left-0 w-full h-full bg-bg-light dark:bg-bg-dark flex justify-center items-center z-[9999] transition-opacity duration-500">
      <div className="text-center">
        <div className="w-12 h-12 border-4 border-surface-light dark:border-surface-dark border-t-primary-light dark:border-t-primary-dark rounded-full animate-spin mx-auto mb-4"></div>
        <h3 className="font-space-grotesk text-lg text-text-light dark:text-text-dark">Loading Portfolio...</h3>
      </div>
    </div>
  );
};

export default Loader;
