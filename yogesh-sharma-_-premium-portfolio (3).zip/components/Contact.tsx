import React, { useState, useRef } from 'react';
import Section from './Section';
import { SOCIAL_LINKS_DATA } from '../constants';

const Contact: React.FC = () => {
  const form = useRef<HTMLFormElement>(null);
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [status, setStatus] = useState<'idle' | 'sending' | 'success' | 'error'>('idle');
  const [statusMessage, setStatusMessage] = useState('');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.current) return;

    // EmailJS Credentials
    const serviceID = 'service_bux93xi';
    const templateID = 'template_2nnek5b';
    const publicKey = 'Z0LDnonb2BWg_UDSW';

    // FIX: Removed redundant check for placeholder credentials which caused a compile error.
    // The credentials are now hardcoded, so this check is no longer necessary.

    const emailjs = (window as any).emailjs;
    if (!emailjs) {
        console.error("EmailJS script is not loaded.");
        setStatus('error');
        setStatusMessage('Could not send email. EmailJS is not configured.');
        return;
    }
    
    setStatus('sending');
    setStatusMessage('');

    emailjs.sendForm(serviceID, templateID, form.current, publicKey)
      .then(() => {
        setStatus('success');
        setStatusMessage('Thank you for your message! I will get back to you soon.');
        setFormData({ name: '', email: '', message: '' });
        setTimeout(() => setStatus('idle'), 5000);
      }, (error: any) => {
        setStatus('error');
        setStatusMessage('Oops! Something went wrong. Please try again later.');
        console.error('FAILED...', error);
        setTimeout(() => setStatus('idle'), 5000);
      });
  };

  return (
    <Section id="contact" title="Get In Touch">
      <div className="grid md:grid-cols-2 gap-12">
        <div>
          <h3 className="text-2xl font-bold font-space-grotesk mb-4 text-accent-light dark:text-accent-dark">Let's Work Together</h3>
          <p className="mb-8 text-text-light dark:text-text-dark/90">
            I'm always interested in new opportunities and exciting projects. Whether you have a question or just want to say hi, feel free to reach out!
          </p>
          <div className="space-y-4 mb-8">
            <div className="flex items-center gap-4 text-text-light dark:text-text-dark">
              <i className="fas fa-phone text-primary-light dark:text-primary-dark w-5 text-center"></i>
              <span>942-590-3357</span>
            </div>
            <div className="flex items-center gap-4 text-text-light dark:text-text-dark">
              <i className="fas fa-envelope text-primary-light dark:text-primary-dark w-5 text-center"></i>
              <span>yogeshsharma9425903357@gmail.com</span>
            </div>
            <div className="flex items-center gap-4 text-text-light dark:text-text-dark">
              <i className="fas fa-map-marker-alt text-primary-light dark:text-primary-dark w-5 text-center"></i>
              <span>Indore, Madhya Pradesh, India</span>
            </div>
          </div>
           <div className="flex gap-4">
              {SOCIAL_LINKS_DATA.map(link => (
                  <a key={link.name} href={link.url} target="_blank" rel="noopener noreferrer" aria-label={link.name} className="w-10 h-10 flex items-center justify-center rounded-full bg-primary-light dark:bg-primary-dark text-white dark:text-bg-dark hover:bg-primary-strong-light dark:hover:bg-primary-strong-dark transition-all duration-300">
                      <i className={link.icon}></i>
                  </a>
              ))}
          </div>
        </div>
        <div>
          <form ref={form} onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="name" className="block text-sm font-medium mb-1 text-text-light dark:text-text-dark">Name</label>
              <input type="text" name="name" id="name" required value={formData.name} onChange={handleChange} className="w-full p-3 rounded-md bg-white/10 dark:bg-surface-dark/10 border-2 border-white/30 dark:border-surface-dark/30 backdrop-blur-sm focus:bg-white/20 dark:focus:bg-surface-dark/20 transition-colors duration-300 focus:ring-primary-light dark:focus:ring-primary-dark outline-none text-text-light dark:text-text-dark" />
            </div>
            <div>
              <label htmlFor="email" className="block text-sm font-medium mb-1 text-text-light dark:text-text-dark">Email</label>
              <input type="email" name="email" id="email" required value={formData.email} onChange={handleChange} className="w-full p-3 rounded-md bg-white/10 dark:bg-surface-dark/10 border-2 border-white/30 dark:border-surface-dark/30 backdrop-blur-sm focus:bg-white/20 dark:focus:bg-surface-dark/20 transition-colors duration-300 focus:ring-primary-light dark:focus:ring-primary-dark outline-none text-text-light dark:text-text-dark" />
            </div>
            <div>
              <label htmlFor="message" className="block text-sm font-medium mb-1 text-text-light dark:text-text-dark">Message</label>
              <textarea name="message" id="message" required rows={5} value={formData.message} onChange={handleChange} className="w-full p-3 rounded-md bg-white/10 dark:bg-surface-dark/10 border-2 border-white/30 dark:border-surface-dark/30 backdrop-blur-sm focus:bg-white/20 dark:focus:bg-surface-dark/20 transition-colors duration-300 focus:ring-primary-light dark:focus:ring-primary-dark outline-none text-text-light dark:text-text-dark resize-vertical"></textarea>
            </div>
            <button type="submit" disabled={status === 'sending'} className="bg-primary-strong-light dark:bg-primary-strong-dark hover:bg-opacity-90 text-white font-bold py-3 px-6 rounded-lg transition-all duration-300 hover:scale-105 w-full disabled:opacity-50 disabled:cursor-not-allowed">
              {status === 'sending' ? 'Sending...' : 'Send Message'}
            </button>
          </form>
          {status !== 'idle' && status !== 'sending' && (
            <p className={`mt-4 text-center text-sm font-medium ${status === 'success' ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
              {statusMessage}
            </p>
          )}
        </div>
      </div>
    </Section>
  );
};

export default Contact;