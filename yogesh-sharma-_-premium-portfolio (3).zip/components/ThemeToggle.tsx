
import React from 'react';
import { useTheme } from '../hooks/useTheme';

const ThemeToggle: React.FC = () => {
  const { theme, setTheme } = useTheme();

  const handleToggle = () => {
    setTheme(theme === 'light' ? 'dark' : 'light');
  };

  return (
    <div className="flex items-center gap-4">
        <span className="text-sm font-medium text-text-light dark:text-text-dark">Light</span>
        <label htmlFor="theme-toggle" className="relative inline-block w-14 h-8 cursor-pointer">
            <input 
                type="checkbox" 
                id="theme-toggle" 
                className="opacity-0 w-0 h-0" 
                checked={theme === 'dark'}
                onChange={handleToggle}
            />
            <span className="absolute top-0 left-0 right-0 bottom-0 bg-primary-light dark:bg-muted-dark rounded-full transition-colors duration-300"></span>
            <span className={`absolute top-1 left-1 w-6 h-6 bg-white rounded-full transition-transform duration-300 transform ${theme === 'dark' ? 'translate-x-6' : 'translate-x-0'}`}>
                <div className={`absolute inset-0 flex items-center justify-center transition-opacity duration-300 ${theme === 'light' ? 'opacity-100' : 'opacity-0'}`}>
                    <i className="fas fa-sun text-yellow-500"></i>
                </div>
                <div className={`absolute inset-0 flex items-center justify-center transition-opacity duration-300 ${theme === 'dark' ? 'opacity-100' : 'opacity-0'}`}>
                    <i className="fas fa-moon text-blue-300"></i>
                </div>
            </span>
        </label>
        <span className="text-sm font-medium text-text-light dark:text-text-dark">Dark</span>
    </div>
  );
};

export default ThemeToggle;