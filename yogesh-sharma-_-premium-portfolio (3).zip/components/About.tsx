import React from 'react';
import Section from './Section';
import { CERTIFICATIONS_DATA } from '../constants';

const About: React.FC = () => {
    return (
        <Section id="about" title="About Me">
            <div className="grid md:grid-cols-2 gap-12 items-center">
                <div className="flex justify-center">
                    <img src="https://i.pinimg.com/736x/4b/1f/46/4b1f463762bdca5880dc1b6b8982b9ca.jpg" alt="Yogesh Sharma" className="rounded-lg shadow-2xl w-full max-w-md object-cover"/>
                </div>
                <div>
                    <h3 className="text-2xl font-bold font-space-grotesk mb-4 text-accent-light dark:text-accent-dark">Developer & Business Alchemist</h3>
                    <p className="mb-4 text-text-light dark:text-text-dark/90">
                        I'm a passionate developer with expertise in creating digital solutions that bridge technology and business needs. With a focus on user experience and clean code, I transform complex problems into elegant solutions.
                    </p>
                    <p className="mb-8 text-text-light dark:text-text-dark/90">
                        My approach combines technical expertise with strategic thinking to deliver products that not only function flawlessly but also drive business growth.
                    </p>

                    <h4 className="text-xl font-bold font-space-grotesk mb-4 text-accent-light dark:text-accent-dark">Certifications & Achievements</h4>
                    <div className="flex flex-wrap gap-3">
                        {CERTIFICATIONS_DATA.map((cert) => (
                            <div key={cert.name} className="flex items-center bg-white/20 dark:bg-surface-dark/20 backdrop-blur-lg shadow-lg border border-white/30 dark:border-surface-dark/30 py-2 px-4 rounded-full transition-transform duration-300 hover:scale-105">
                                <i className={`${cert.icon} mr-2 text-primary-light dark:text-primary-dark`}></i>
                                <span className="text-sm font-medium text-text-light dark:text-text-dark">{cert.name}</span>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </Section>
    );
};

export default About;