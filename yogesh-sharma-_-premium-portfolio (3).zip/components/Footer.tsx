
import React from 'react';
import { SOCIAL_LINKS_DATA } from '../constants';

const Footer: React.FC = () => {
    return (
        <footer className="bg-white/10 dark:bg-surface-dark/10 backdrop-blur-lg py-12 text-center">
            <div className="container mx-auto px-4">
                <div className="font-space-grotesk font-bold text-2xl mb-4 text-primary-strong-light dark:text-primary-strong-dark">
                    Yogesh Sharma
                </div>
                <div className="flex justify-center gap-4 mb-6">
                    {SOCIAL_LINKS_DATA.map(link => (
                        <a key={link.name} href={link.url} target="_blank" rel="noopener noreferrer" aria-label={link.name} className="w-10 h-10 flex items-center justify-center rounded-full bg-primary-light dark:bg-primary-dark text-white dark:text-bg-dark hover:bg-primary-strong-light dark:hover:bg-primary-strong-dark transition-all duration-300">
                            <i className={link.icon}></i>
                        </a>
                    ))}
                </div>
                <p className="text-text-light dark:text-text-dark/80">&copy; {new Date().getFullYear()} All Rights Reserved</p>
            </div>
        </footer>
    );
};

export default Footer;