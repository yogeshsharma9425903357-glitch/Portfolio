
import React from 'react';
import Section from './Section';
import { SKILLS_DATA } from '../constants';
import type { SkillCategory as SkillCategoryType } from '../types';

const SkillCategory: React.FC<{ category: SkillCategoryType }> = ({ category }) => (
    <div className="bg-white/20 dark:bg-surface-dark/20 backdrop-blur-lg p-6 rounded-xl shadow-xl border border-white/30 dark:border-surface-dark/30 transition-all duration-300 hover:shadow-2xl hover:-translate-y-2">
        <h3 className="text-xl font-bold font-space-grotesk mb-4 text-primary-light dark:text-primary-dark border-b-2 border-muted-light dark:border-muted-dark pb-2">
            {category.title}
        </h3>
        <div className="flex flex-wrap gap-3">
            {category.skills.map((skill) => (
                <span key={skill.name} className="bg-primary-light dark:bg-primary-dark text-white dark:text-bg-dark py-2 px-4 rounded-full text-sm font-semibold transition-colors duration-300 hover:bg-primary-strong-light dark:hover:bg-primary-strong-dark">
                    {skill.name}
                </span>
            ))}
        </div>
    </div>
);


const Skills: React.FC = () => {
    return (
        <Section id="skills" title="Technical Skills & Expertise">
            <div className="grid sm:grid-cols-2 lg:grid-cols-2 gap-8">
                {SKILLS_DATA.map((category) => (
                    <SkillCategory key={category.title} category={category} />
                ))}
            </div>
        </Section>
    );
};

export default Skills;