import React from 'react';
import { useTypewriter } from '../hooks/useTypewriter';

const Hero: React.FC = () => {
    const roles = ['Developer', 'Business Alchemist', 'Creative Thinker'];
    const typedRole = useTypewriter(roles);

    const handleScrollTo = (e: React.MouseEvent<HTMLAnchorElement>, selector: string) => {
        e.preventDefault();
        const targetElement = document.querySelector(selector);
        if (targetElement) {
            const offsetTop = (targetElement as HTMLElement).offsetTop;
            window.scrollTo({
                top: offsetTop - 80, // Adjust for header height
                behavior: 'smooth',
            });
        }
    };

    return (
        <section id="home" className="min-h-screen flex items-center pt-24 pb-12">
            <div className="container mx-auto px-4">
                <div className="grid md:grid-cols-2 gap-12 items-center">
                    <div className="hero-text text-center md:text-left">
                        <h1 className="font-space-grotesk text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight mb-4 text-primary-strong-light dark:text-primary-strong-dark">
                            Yogesh Sharma
                        </h1>
                        <h2 className="font-space-grotesk text-3xl sm:text-4xl lg:text-5xl font-bold mb-6 min-h-[50px] sm:min-h-[60px] lg:min-h-[70px]">
                            <span className="text-text-light dark:text-text-dark">{typedRole}</span>
                            <span className="animate-[blink_0.75s_step-end_infinite] border-r-4 border-primary-light dark:border-primary-dark"></span>
                        </h2>
                        <style>{`
                            @keyframes blink {
                                from, to { border-color: transparent }
                                50% { border-color: inherit; }
                            }
                        `}</style>

                        <p className="text-lg mb-8 text-text-light dark:text-text-dark/80">
                            I create digital experiences that blend innovation with functionality, turning ideas into impactful solutions.
                        </p>
                        <div className="flex flex-wrap justify-center md:justify-start gap-4">
                             <a href="#projects" onClick={(e) => handleScrollTo(e, '#projects')} className="inline-block bg-primary-strong-light hover:bg-opacity-80 text-white font-bold py-2 px-4 text-sm sm:py-3 sm:px-6 sm:text-base rounded-lg transition-transform duration-300 hover:scale-105">
                                View My Work
                            </a>
                            <a href="#contact" onClick={(e) => handleScrollTo(e, '#contact')} className="inline-block bg-surface-light dark:bg-surface-dark border-2 border-primary-strong-light dark:border-primary-strong-dark text-primary-strong-light dark:text-primary-strong-dark font-bold py-2 px-4 text-sm sm:py-3 sm:px-6 sm:text-base rounded-lg transition-transform duration-300 hover:scale-105">
                                Contact Me
                            </a>
                        </div>
                    </div>
                    <div className="flex justify-center">
                        <div className="group hero-card-flipper w-[250px] h-[333px] sm:w-[300px] sm:h-[400px] [perspective:1000px]">
                            <div className="relative w-full h-full rounded-xl shadow-2xl transition-all duration-700 [transform-style:preserve-3d] group-hover:[transform:rotateY(180deg)]">
                                <div className="absolute inset-0">
                                    <img className="w-full h-full object-cover rounded-xl" src="https://i.pinimg.com/736x/a1/c2/91/a1c291061bd06c26a9ebc030c2ea9802.jpg" alt="Yogesh Sharma Front" />
                                </div>
                                <div className="absolute inset-0 [transform:rotateY(180deg)] [backface-visibility:hidden]">
                                    <img className="w-full h-full object-cover rounded-xl" src="https://i.pinimg.com/736x/57/59/13/575913cd2df0cc2c809bad44a548d3a3.jpg" alt="Yogesh Sharma Back" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Hero;