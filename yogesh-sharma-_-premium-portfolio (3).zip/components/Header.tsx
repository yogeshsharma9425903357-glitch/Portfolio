
import React, { useState, useEffect } from 'react';
import ThemeToggle from './ThemeToggle';
import { NAV_LINKS } from '../constants';

const Header: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setIsMenuOpen(false); // Close mobile menu on link click
    const targetElement = document.querySelector(href);
    if (targetElement) {
      const offsetTop = (targetElement as HTMLElement).offsetTop;
      window.scrollTo({
        top: offsetTop - 80, // Adjust for header height
        behavior: 'smooth',
      });
    }
  };

  return (
    <header className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${isScrolled ? 'py-4 bg-surface-light/20 dark:bg-surface-dark/20 backdrop-blur-lg shadow-lg' : 'py-6'}`}>
      <div className="container mx-auto px-4 flex justify-between items-center">
        <div className="font-space-grotesk font-bold text-2xl text-primary-strong-light dark:text-primary-strong-dark">
          Yogesh Sharma
        </div>
        <nav className="hidden md:flex items-center gap-8">
          {NAV_LINKS.map(link => (
            <a 
              key={link.href} 
              href={link.href} 
              onClick={(e) => handleNavClick(e, link.href)}
              className="font-medium text-text-light dark:text-text-dark relative after:content-[''] after:absolute after:left-0 after:bottom-[-4px] after:w-0 after:h-[2px] after:bg-primary-light after:dark:bg-primary-dark after:transition-all after:duration-300 hover:text-primary-light dark:hover:text-primary-dark hover:after:w-full"
            >
              {link.label}
            </a>
          ))}
        </nav>
        <div className="hidden md:block">
          <ThemeToggle />
        </div>
        <div className="md:hidden">
          <button onClick={() => setIsMenuOpen(!isMenuOpen)} aria-label="Toggle menu" className="text-primary-strong-light dark:text-primary-strong-dark text-2xl">
            <i className={`fas ${isMenuOpen ? 'fa-times' : 'fa-bars'}`}></i>
          </button>
        </div>
      </div>
      {/* Mobile Menu */}
      <div className={`absolute top-full left-0 w-full bg-bg-light/95 dark:bg-bg-dark/95 backdrop-blur-lg md:hidden overflow-hidden transition-all duration-300 ease-in-out ${isMenuOpen ? 'max-h-screen shadow-lg' : 'max-h-0'}`}>
        <nav className="flex flex-col items-center gap-4 p-4">
          {NAV_LINKS.map(link => (
            <a 
              key={link.href} 
              href={link.href} 
              onClick={(e) => handleNavClick(e, link.href)}
              className="font-medium text-text-light dark:text-text-dark w-full text-center py-2"
            >
              {link.label}
            </a>
          ))}
          <div className="mt-4">
            <ThemeToggle />
          </div>
        </nav>
      </div>
    </header>
  );
};

export default Header;