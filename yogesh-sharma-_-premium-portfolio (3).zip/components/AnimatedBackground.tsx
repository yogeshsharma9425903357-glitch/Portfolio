import React from 'react';

const AnimatedBackground: React.FC = () => {
  const particles = Array.from({ length: 15 });

  return (
    <div className="particles" aria-hidden="true">
      {particles.map((_, i) => (
        <div key={i} className="particle"></div>
      ))}
    </div>
  );
};

export default AnimatedBackground;
