
import type { Project, SkillCategory, Certification, SocialLink } from './types';

export const NAV_LINKS = [
  { href: '#home', label: 'Home' },
  { href: '#about', label: 'About Me' },
  { href: '#skills', label: 'Skills & Expertise' },
  { href: '#projects', label: 'Projects' },
  { href: '#contact', label: 'Contact' },
];

export const SKILLS_DATA: SkillCategory[] = [
  {
    title: "Programming & Development",
    skills: [
      { name: "Full-stack Development" },
      { name: "Python Programming" },
      { name: "System Architecture" },
      { name: "Debugging & Testing" },
      { name: "Cloud Computing" },
      { name: "AI/ML" },
      { name: "UI/UX Design" },
      { name: "Graphics Design" },
      { name: "Content Creation" },
    ],
  },
  {
    title: "Data & Analytics",
    skills: [
      { name: "Data Analytics" },
      { name: "Databases" },
      { name: "Google Analytics" },
      { name: "Business Intelligence" },
      { name: "Performance Tracking" },
      { name: "User Behavior Analysis" },
    ],
  },
  {
    title: "Cybersecurity",
    skills: [
      { name: "Government Cybersecurity" },
      { name: "Security Implementation" },
      { name: "Protocols" },
      { name: "IT Fundamentals" },
    ],
  },
  {
    title: "Business & Marketing",
    skills: [
      { name: "Digital Marketing" },
      { name: "SEO Optimization" },
      { name: "PPC Campaigns" },
      { name: "Business Process Analysis" },
      { name: "Leadership" },
      { name: "Team Management" },
      { name: "Strategic Thinking" },
      { name: "Cross-cultural Communication" },
    ],
  },
];

export const PROJECTS_DATA: Project[] = [
    {
        title: "E commerce sites",
        description: "A full-stack e-commerce solution with payment integration, user authentication, and admin dashboard.",
        imageUrl: "https://www.liveconnectevent.com/wp-content/uploads/2022/08/E-Commerce-1024x683.jpeg",
        liveUrl: "#",
        sourceUrl: "#",
    },
    {
        title: "Task Management",
        description: "A productivity application for managing tasks with drag-and-drop functionality and team collaboration.",
        imageUrl: "https://snacknation.com/wp-content/uploads/2020/12/Best-Task-Management-Software-Platforms.png",
        liveUrl: "#",
        sourceUrl: "#",
    },
    {
        title: "Social Media Marketing",
        description: "Dashboard for tracking social media performance and managing marketing campaigns with data visualization.",
        imageUrl: "https://entail.mayple.com/en-assets/mayple/socialmediamanagement-1702282769682.jpg",
        liveUrl: "#",
        sourceUrl: "#",
    },
    {
        title: "Digital Marketing",
        description: "Integrated marketing solution with SEO tools, campaign management, and analytics.",
        imageUrl: "https://www.monkeydigital.org/wp-content/uploads/2025/05/Best-Digital-Marketing-Agencies-In-Mumbai.jpg",
        liveUrl: "#",
        sourceUrl: "#",
    },
    {
        title: "Content Creation & Writer",
        description: "A platform for showcasing written content, managing a portfolio of articles, and engaging with readers.",
        imageUrl: "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgBe2Pnsh3DSXtZAJzrKmM7FuFmQQHPSP4WxvdcBo2S922E0kObyqZY-RQWrig8jmSeEGmfeHV_KxQEK8Ahzog0ItcZMRHFe-QqL_JNYb7OGWMCVquU1-9O8lsiXPJPCo_sUFty0ERYxL_4TcF85p6fARfLPlF57Ld15VGYfD2aFsCY7r0VcQYr-ZKj/s16000/penghasilan%20Content%20Creator.JPG",
        liveUrl: "#",
        sourceUrl: "#",
    },
    {
        title: "Website Designer",
        description: "A collection of visually stunning and user-friendly websites designed to meet diverse client needs.",
        imageUrl: "https://storage.googleapis.com/ureify-strapi-assets/web_developer_resume_4906271445/web_developer_resume_4906271445.jpeg",
        liveUrl: "#",
        sourceUrl: "#",
    },
     {
        title: "Research Paper & Projects",
        description: "An archive of academic research papers and innovative projects, highlighting analytical and problem-solving skills.",
        imageUrl: "https://ijird.com/wp-content/uploads/2022/10/IJIRD_5-Ways-to-Become-an-Independent-Researcher_Blog-Image.jpg",
        liveUrl: "#",
        sourceUrl: "#",
    },
    {
        title: "NFT Projects & Design",
        description: "A showcase of unique NFT collections and digital art, exploring the intersection of creativity and blockchain technology.",
        imageUrl: "https://img2.storyblok.com/1220x686/filters:format(webp)/f/102932/1920x1080/156ed23596/monkey-g46eb24a10_1920.jpg",
        liveUrl: "#",
        sourceUrl: "#",
    },
];


export const CERTIFICATIONS_DATA: Certification[] = [
    { name: "Google Analytics Certified", icon: "fas fa-award" },
    { name: "MeitY ISEA Cybersecurity", icon: "fas fa-shield-alt" },
    { name: "25+ Technical Certifications", icon: "fas fa-certificate" },
    { name: "University AI Coursework", icon: "fas fa-robot" },
    { name: "96% Digital Marketing Certification", icon: "fas fa-chart-line" }
];

export const SOCIAL_LINKS_DATA: SocialLink[] = [
    { name: 'GitHub', url: 'https://github.com/yogeshsharma9425903357-glitch', icon: 'fab fa-github' },
    { name: 'LinkedIn', url: 'https://www.linkedin.com/in/yogesh-sharma-9312022b9/', icon: 'fab fa-linkedin' },
    { name: 'Twitter', url: 'https://x.com/VisionX_07', icon: 'fab fa-twitter' },
    { name: 'Instagram', url: 'https://www.instagram.com/ysmp._.artist/', icon: 'fab fa-instagram' },
];