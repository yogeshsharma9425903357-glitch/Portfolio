
export interface Project {
  title: string;
  description: string;
  imageUrl: string;
  liveUrl: string;
  sourceUrl: string;
}

export interface Skill {
  name: string;
}

export interface SkillCategory {
  title: string;
  skills: Skill[];
}

export interface Certification {
  name: string;
  icon: string;
}

export interface SocialLink {
  name: string;
  url: string;
  icon: string;
}
