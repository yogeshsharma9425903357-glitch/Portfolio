
import { useState, useEffect } from 'react';

export const useTypewriter = (roles: string[], typingDelay = 100, erasingDelay = 50, newRoleDelay = 1000) => {
  const [text, setText] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);
  const [roleIndex, setRoleIndex] = useState(0);
  const [charIndex, setCharIndex] = useState(0);

  useEffect(() => {
    // FIX: Added a guard clause to prevent a runtime error if the `roles` array is empty.
    // This ensures the component doesn't crash if no roles are provided.
    if (!roles || roles.length === 0) {
      return;
    }
      
    const handleTyping = () => {
      const currentRole = roles[roleIndex];
      
      if (isDeleting) {
        setText(currentRole.substring(0, charIndex - 1));
        setCharIndex(prev => prev - 1);
      } else {
        setText(currentRole.substring(0, charIndex + 1));
        setCharIndex(prev => prev + 1);
      }
      
      if (!isDeleting && charIndex === currentRole.length) {
        setTimeout(() => setIsDeleting(true), newRoleDelay);
      } else if (isDeleting && charIndex === 0) {
        setIsDeleting(false);
        setRoleIndex(prev => (prev + 1) % roles.length);
      }
    };

    const typingTimeout = setTimeout(handleTyping, isDeleting ? erasingDelay : typingDelay);
    
    return () => clearTimeout(typingTimeout);
  }, [charIndex, isDeleting, roleIndex, roles, typingDelay, erasingDelay, newRoleDelay]);

  return text;
};
